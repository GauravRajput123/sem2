const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',           
  password: 'Pass@123', 
  database: 'customer' 
});

connection.connect(err => {
  if (err) {
    console.error('Connection error:', err);
    return;
  }
  console.log('Connected to MySQL');
});

const query = "SELECT * FROM customers WHERE name LIKE 'A%'";

connection.query(query, (err, results) => {
  if (err) {
    console.error('Query error:', err);
  } else {
    console.log('Customers whose name starts with A:');
    console.log(results);
  }

  connection.end();
});
