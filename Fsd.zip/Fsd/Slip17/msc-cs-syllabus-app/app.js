// app.js
angular.module('syllabusApp', ['ngRoute'])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'templates/home.html',
      })
      .when('/subject1', {
        templateUrl: 'templates/subject1.html',
      })
      .when('/subject2', {
        templateUrl: 'templates/subject2.html',
      })
      .when('/subject3', {
        templateUrl: 'templates/subject3.html',
      })
      .otherwise({
        redirectTo: '/',
      });
  });