const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',         
  password: 'Pass@123', 
  database: 'customer'     
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL!');

  const query = 'SELECT * FROM customers';

  connection.query(query, (err, results, fields) => {
    if (err) throw err;

    console.log('All Customers:');
    console.log(results); 
    connection.end();
  });
});
