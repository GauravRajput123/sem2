const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Pass@123',
    database: 'teachers'

});

connection.connect((err) => {
    if(err) {
        console.error('Error connecting: ' + err.stack);
        return;
    }
    console.log('Connect as id ' + connection.threadId);

    connection.query('SELECT * FROM teacher where Tsalary=20000', (error, results) => {
        if(error) throw error;
        console.log('User Data:', results);

        connection.end();
    });

});