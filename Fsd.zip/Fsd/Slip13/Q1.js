const inputString = "HELLO WORLD!";
const lowerCaseString = inputString.toLowerCase();
console.log(lowerCaseString);