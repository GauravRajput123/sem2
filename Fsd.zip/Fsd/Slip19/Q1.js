// convertTouppercase.js

// Input string
const inputString = "Hello World!";

// Convert the string to uppercase
const upperCaseString = inputString.toUpperCase();

// Output the result
console.log(upperCaseString);