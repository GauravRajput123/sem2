const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

// Create a directory for files if it doesn't exist
const filesDir = path.join(__dirname, 'files');
if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir);
}

// Route to display download links
app.get('/', (req, res) => {
    // Get list of files in the files directory
    fs.readdir(filesDir, (err, files) => {
        if (err) {
            return res.status(500).send('Error reading files directory');
        }

        // Create HTML with download links
        let html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>File Downloader</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #333; }
                    ul { list-style-type: none; padding: 0; }
                    li { margin: 10px 0; }
                    a { color: #0066cc; text-decoration: none; }
                    a:hover { text-decoration: underline; }
                </style>
            </head>
            <body>
                <h1>Available Files</h1>
                <ul>
        `;

        if (files.length === 0) {
            html += '<li>No files available for download</li>';
        } else {
            files.forEach(file => {
                html += `<li><a href="/download/${file}">${file}</a></li>`;
            });
        }

        html += `
                </ul>
                <p>Upload files to the "files" directory to make them available for download.</p>
            </body>
            </html>
        `;

        res.send(html);
    });
});

// Route to handle file downloads
app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(filesDir, filename);

    // Check if file exists
    if (fs.existsSync(filePath)) {
        // Set headers to prompt download
        res.download(filePath, filename, (err) => {
            if (err) {
                console.error('Error downloading file:', err);
                res.status(500).send('Error downloading file');
            }
        });
    } else {
        res.status(404).send('File not found');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
    console.log(`Place files in the "files" directory to make them available for download`);
});