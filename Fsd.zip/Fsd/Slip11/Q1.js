const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost', 
  user: 'root',
  password: 'Pass@123',
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL server');

  connection.query('CREATE DATABASE IF NOT EXISTS movie', (err) => {
    if (err) {
      console.error('Error creating database:', err);
      return;
    }
    console.log('Database "movie" created or already exists');

    connection.query('USE movie', (err) => {
      if (err) {
        console.error('Error switching to database:', err);
        return;
      }
      console.log('Using database "movie"');

      const createTableQuery = `
        CREATE TABLE IF NOT EXISTS movies (
          id INT AUTO_INCREMENT PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          director VARCHAR(255) NOT NULL,
          release_year INT NOT NULL,
          genre VARCHAR(100) NOT NULL
        )
      `;
      connection.query(createTableQuery, (err) => {
        if (err) {
          console.error('Error creating table:', err);
          return;
        }
        console.log('Table "movies" created or already exists');


        connection.end();
        console.log('Connection closed');
      });
    });
  });
});