const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('views')); // To serve index.html

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.post('/append', (req, res) => {
  const source = req.body.source;
  const destination = req.body.destination;

  fs.readFile(source, 'utf8', (err, data) => {
    if (err) {
      return res.send(`Error reading source file: ${err.message}`);
    }

    fs.appendFile(destination, data, (err) => {
      if (err) {
        return res.send(`Error appending to destination file: ${err.message}`);
      }

      res.send(`Successfully appended content from "${source}" to "${destination}"`);
    });
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
