const reverseString = (str) => {
    return str.split('').reverse().join('');
};

const output = "Full Stack!";
console.log(reverseString(output));
