const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',            
  password: 'Pass@123' 
});

connection.query('CREATE DATABASE IF NOT EXISTS studentDB', (err, result) => {
  if (err) throw err;
  console.log('Database "studentDB" created or already exists.');

  const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Pass@123',
    database: 'studentDB'
  });

  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS students (
      id INT AUTO_INCREMENT PRIMARY KEY,
      first_name VARCHAR(50),
      last_name VARCHAR(50),
      age INT,
      email VARCHAR(100)
    )
  `;

  db.query(createTableQuery, (err, result) => {
    if (err) throw err;
    console.log('Table "students" created or already exists.');
    db.end(); 
  });
});
