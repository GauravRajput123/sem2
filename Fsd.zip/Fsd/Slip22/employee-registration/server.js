const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

// Handle form submission
app.post('/register', (req, res) => {
  const { name, email, phone, department } = req.body;

  // Server-side validation
  const nameRegex = /^[a-zA-Z ]+$/;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[0-9]{10}$/;

  if (!name || !email || !phone || !department) {
    return res.send("All fields are required.");
  }
  if (!nameRegex.test(name)) {
    return res.send("Invalid name.");
  }
  if (!emailRegex.test(email)) {
    return res.send("Invalid email.");
  }
  if (!phoneRegex.test(phone)) {
    return res.send("Invalid phone number.");
  }

  res.send(`Employee ${name} from ${department} registered successfully!`);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
