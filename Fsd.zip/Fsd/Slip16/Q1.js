const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',        
  password: 'Pass@123', 
  database: 'recipebook'
});

db.connect((err) => {
  if (err) {
    console.error('MySQL connection error:', err);
    return;
  }
  console.log('Connected to MySQL!');
});

// Get all recipes
app.get('/recipes', (req, res) => {
  db.query('SELECT * FROM recipes', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

// Get a specific recipe
app.get('/recipes/:id', (req, res) => {
  db.query('SELECT * FROM recipes WHERE id = ?', [req.params.id], (err, results) => {
    if (err) return res.status(500).send(err);
    if (results.length === 0) return res.status(404).send({ message: 'Recipe not found' });
    res.json(results[0]);
  });
});

// Add a recipe
app.post('/recipes', (req, res) => {
  const { name, ingredients, instructions } = req.body;
  const sql = 'INSERT INTO recipes (name, ingredients, instructions) VALUES (?, ?, ?)';
  db.query(sql, [name, ingredients, instructions], (err, result) => {
    if (err) return res.status(500).send(err);
    res.status(201).send({ message: 'Recipe added!', id: result.insertId });
  });
});

// Delete a recipe
app.delete('/recipes/:id', (req, res) => {
  db.query('DELETE FROM recipes WHERE id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    if (result.affectedRows === 0) return res.status(404).send({ message: 'Recipe not found' });
    res.send({ message: 'Recipe deleted' });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Recipe Book API running at http://localhost:${port}`);
});
