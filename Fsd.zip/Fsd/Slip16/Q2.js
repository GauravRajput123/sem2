const EventEmitter = require('events');

class MyEmitter extends EventEmitter {}

const myEmitter = new MyEmitter();

myEmitter.on('greet', (name) => {
  console.log(`Hello, ${name}!`);
});

myEmitter.on('exit', () => {
  console.log('Goodbye!');
  process.exit();
});

const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

console.log('Event-driven application started. Type "greet <name>" or "exit" to trigger events.');

rl.on('line', (input) => {
  const [command, ...args] = input.split(' ');

  if (command === 'greet') {
    const name = args.join(' ');
    if (name) {
      myEmitter.emit('greet', name); 
    } else {
      console.log('Please provide a name.');
    }
  } else if (command === 'exit') {
    myEmitter.emit('exit');
  } else {
    console.log('Unknown command. Try "greet <name>" or "exit".');
  }
});