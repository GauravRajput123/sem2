// modules.js
function getCurrentDateTime() {
    const now = new Date();
    return now.toLocaleString(); // Returns the current date and time in a readable format
  }
  
  // Export the function
  module.exports = getCurrentDateTime;