const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost', 
  user: 'root', 
  password: 'Pass@123', 
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL server');

  connection.query('CREATE DATABASE IF NOT EXISTS college', (err) => {
    if (err) {
      console.error('Error creating database:', err);
      return;
    }
    console.log('Database "college" created or already exists');

    connection.query('USE college', (err) => {
      if (err) {
        console.error('Error switching to database:', err);
        return;
      }
      console.log('Using database "college"');

      const createTableQuery = `
        CREATE TABLE IF NOT EXISTS students (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          age INT NOT NULL,
          grade VARCHAR(10) NOT NULL
        )
      `;
      connection.query(createTableQuery, (err) => {
        if (err) {
          console.error('Error creating table:', err);
          return;
        }
        console.log('Table "students" created or already exists');

        connection.end();
        console.log('Connection closed');
      });
    });
  });
});